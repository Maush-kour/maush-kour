
const YAPE_NUMBER = '+51 924 899 004';
const MIN_AGE = 18;
function qs(s){return document.querySelector(s)}
function qsa(s){return document.querySelectorAll(s)}

/* Auth */
function openModal(id){qs('#'+id).style.display='flex'}
function closeModal(id){qs('#'+id).style.display='none'}
function showRegisterStep2(){qs('#regStep1').style.display='none';qs('#regStep2').style.display='block'}
function showRegisterStep1(){qs('#regStep1').style.display='block';qs('#regStep2').style.display='none'}

function doRegister(){
  const name = qs('#regName').value.trim();
  const email = qs('#regEmail').value.trim();
  const pass = qs('#regPass').value;
  const pass2 = qs('#regPass2').value;
  if(!name||!email||!pass||!pass2){alert('Completa todos los campos.');return;}
  if(pass!==pass2){alert('Contraseñas no coinciden.');return;}
  // save simple user
  let users = JSON.parse(localStorage.getItem('mk_users')||'[]');
  if(users.find(u=>u.email===email)){alert('Correo ya registrado.');return;}
  users.push({email,name,pass});
  localStorage.setItem('mk_users', JSON.stringify(users));
  alert('Cuenta creada. Ahora completa fecha de nacimiento.');
  showRegisterStep2();
}
function finalizeRegistration(){
  const dob = qs('#regBirth').value;
  const phone = qs('#regPhone').value.trim();
  if(!dob || !phone){alert('Completa fecha de nacimiento y teléfono.'); return;}
  const age = ageFrom(dob);
  if(age < MIN_AGE){alert('Debes tener al menos '+MIN_AGE+' años.'); return;}
  alert('Registro completado. Ya puedes iniciar sesión.');
  closeModal('authModal');
}

function ageFrom(dob){
  return new Date(Date.now() - new Date(dob).getTime()).getUTCFullYear() - 1970;
}

function doLogin(){
  const email = qs('#loginEmail').value.trim();
  const pass = qs('#loginPass').value;
  let users = JSON.parse(localStorage.getItem('mk_users')||'[]');
  const u = users.find(x=>x.email===email && x.pass===pass);
  if(!u){alert('Usuario no encontrado o contraseña incorrecta.');return;}
  localStorage.setItem('mk_session', JSON.stringify({email:u.email,name:u.name}));
  alert('Sesión iniciada: '+u.name);
  closeModal('authModal');
  refreshAuthUI();
}

function refreshAuthUI(){
  const s = JSON.parse(localStorage.getItem('mk_session')||'null');
  const btn = qs('#authBtnHeader');
  if(s){btn.innerText = 'Hola, '+s.name; btn.onclick = ()=>{localStorage.removeItem('mk_session'); alert('Cerraste sesión'); refreshAuthUI();}}
  else {btn.innerText='Iniciar sesión'; btn.onclick = ()=> openModal('authModal')}
}

/* Cart */
let CART = JSON.parse(localStorage.getItem('mk_cart')||'[]');
function saveCart(){localStorage.setItem('mk_cart', JSON.stringify(CART)); updateCartUI();}
function addCart(id){
  const card = qs('.card[data-id="'+id+'"]');
  CART.push({id, name: card.dataset.name, price: Number(card.dataset.price), colors: card.dataset.colors, size: card.dataset.hasSize});
  saveCart(); alert('Añadido al carrito');
}
function updateCartUI(){
  qs('#openCart').innerText = '🛒 '+CART.length;
  const itemsDiv = qs('#cartItems');
  if(!itemsDiv) return;
  if(CART.length===0){itemsDiv.innerHTML='<div class="small">Carrito vacío</div>'; qs('#cartTotal').innerText='S/. 0.00'; return;}
  itemsDiv.innerHTML=''; let total=0;
  CART.forEach((it,i)=>{ total+=it.price; const d=document.createElement('div'); d.style.display='flex'; d.style.justifyContent='space-between'; d.style.marginBottom='10px'; d.innerHTML='<div><strong>'+it.name+'</strong><div class="small">S/. '+it.price.toFixed(2)+'</div></div><div><button class="btn" onclick="removeFromCart('+i+')">Quitar</button></div>'; itemsDiv.appendChild(d);});
  qs('#cartTotal').innerText = 'S/. '+total.toFixed(2);
}
function removeFromCart(i){CART.splice(i,1); saveCart();}

function openCart(){qs('#cartModal').style.display='flex'; updateCartUI();}
function closeCart(){qs('#cartModal').style.display='none'}

/* Buy flow: shows buy modal then checkout */
function openBuy(id){
  const card = qs('.card[data-id="'+id+'"]');
  const name = card.dataset.name; const price = Number(card.dataset.price).toFixed(2);
  const colors = (card.dataset.colors||'').split(',').map(s=>s.trim());
  const hasSize = card.dataset.hasSize==='yes';
  let html = '<div><strong>'+name+'</strong></div><div class="small">Precio: S/. '+price+'</div>';
  html += '<label>Color (obligatorio)</label><select id="optColor">'+colors.map(c=>'<option>'+c+'</option>').join('')+'</select>';
  if(hasSize) html += '<label>Talla (obligatorio)</label><select id="optSize"><option value="">--Selecciona--</option><option>S</option><option>M</option><option>L</option></select>';
  html += '<label>Nombre</label><input id="buyerName" placeholder="Tu nombre"><label>Teléfono</label><input id="buyerPhone" placeholder="924...">';
  html += '<div style="display:flex;gap:8px;margin-top:10px"><button class="btn btn-buy" onclick="startDirectBuy(\''+id+'\')">Pagar con Yape</button><button class="btn" onclick="closeModal(\'buyModal\')">Cancelar</button></div>';
  qs('#buyBody').innerHTML = html; openModal('buyModal');
}

function startDirectBuy(productId){
  const color = qs('#optColor')?qs('#optColor').value:'';
  const sizeEl = qs('#optSize'); const size = sizeEl?sizeEl.value:'';
  const name = qs('#buyerName').value.trim(); const phone = qs('#buyerPhone').value.trim();
  if(!color){alert('Selecciona color'); return;}
  if(sizeEl && !size){alert('Selecciona talla'); return;}
  if(!name||!phone){alert('Completa nombre y teléfono'); return;}
  // create order
  const product = qs('.card[data-id="'+productId+'"]');
  const order = {id:'ord_'+Date.now(), productId:productId, productName:product.dataset.name, price: Number(product.dataset.price), color, size, buyer:{name,phone}, status:'pending', date:new Date().toISOString()};
  let pending = JSON.parse(localStorage.getItem('mk_pending')||'[]'); pending.push(order); localStorage.setItem('mk_pending', JSON.stringify(pending));
  closeModal('buyModal'); openCheckout(order.id);
}

function openCheckout(orderId){
  openModal('checkoutModal');
  const session = JSON.parse(localStorage.getItem('mk_session')||'null');
  if(!session){ qs('#checkoutUserNotice').style.display='block'; qs('#addressForm').style.display='none'; }
  else { qs('#checkoutUserNotice').style.display='none'; qs('#addressForm').style.display='block'; populateDept(); qs('#checkoutBody').dataset.pendingOrder = orderId || ''; }
}

const departments = { "Lambayeque": {"Chiclayo":["Chiclayo","Mórrope","Túcume","Pimentel"]}, "La Libertad":{"Trujillo":["Trujillo"]}, "Lima":{"Lima":["Lima","Miraflores"]} };
function populateDept(){ const selDept=qs('#selDept'); selDept.innerHTML = '<option value="">--Departamento--</option>'+Object.keys(departments).map(d=>'<option>'+d+'</option>').join(''); selDept.onchange = ()=> onDeptChange(); onDeptChange(); }
function onDeptChange(){ const d = qs('#selDept').value; const selCity=qs('#selCity'); selCity.innerHTML='<option value="">--Ciudad--</option>'; if(!d) return; selCity.innerHTML += Object.keys(departments[d]).map(c=>'<option>'+c+'</option>').join(''); selCity.onchange = ()=> onCityChange(d); }
function onCityChange(dept){ const c = qs('#selCity').value; const selDist = qs('#selDist'); selDist.innerHTML = '<option value="">--Distrito--</option>'; if(!c) return; selDist.innerHTML += departments[dept][c].map(x=>'<option>'+x+'</option>').join(''); updateAddressOptions(dept,c); }
function updateAddressOptions(dept,city){ const selAddress = qs('#selAddressOption'); selAddress.innerHTML='<option value="">--Selecciona opción--</option>'; if(!dept||!city) return; selAddress.innerHTML += '<option>'+city+' - Av. Principal 123</option>'; selAddress.innerHTML += '<option>'+city+' - Jr. Secundaria 45</option>'; }

function confirmPayment(){
  // mark pending order as paid and show success with check
  const pending = JSON.parse(localStorage.getItem('mk_pending')||'[]');
  const orderId = qs('#checkoutBody').dataset.pendingOrder;
  const order = pending.find(o=>o.id===orderId);
  if(!order){ alert('No se encontró el pedido'); return; }
  order.status = 'paid'; order.paidAt = new Date().toISOString();
  // move to orders
  let orders = JSON.parse(localStorage.getItem('mk_orders')||'[]'); orders.push(order); localStorage.setItem('mk_orders', JSON.stringify(orders));
  // remove from pending
  const remaining = pending.filter(o=>o.id!==orderId); localStorage.setItem('mk_pending', JSON.stringify(remaining));
  // show success
  qs('#checkoutSuccess').style.display='block'; qs('#checkoutBody').style.display='none';
  qs('#orderSummary').innerText = 'Pedido: '+order.productName+' — S/. '+order.price.toFixed(2)+' — Enviado a: '+qs('#selDist').value+', '+qs('#selCity').value+', '+qs('#selDept').value;
  // animate check (simple)
  qs('#successText').innerText = '¡Excelente compra! Gracias por elegir Maush Kour';
  setTimeout(()=>{ closeModal('checkoutModal'); alert('Pedido marcado como pagado (demo).'); }, 2200);
}

/* categories filter */
qsa('.categories button').forEach(b=> b.addEventListener('click', ()=>{ const cat=b.dataset.cat; qsa('.grid .card').forEach(card=>{ if(cat==='all' || card.dataset.cat===cat) card.style.display='block'; else card.style.display='none'; }); }));

// init
refreshAuthUI(); updateCartUI();
